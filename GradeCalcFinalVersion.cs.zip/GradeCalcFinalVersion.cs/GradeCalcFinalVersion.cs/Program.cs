﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;



namespace GradeCalcFinalVersion.cs
{
    internal class Program
    {
        static void Main(string[] args)
        {


            bool showMenu = true;
            while (showMenu) // while loop makes sure the program still runs at the end of all functions
            {

                showMenu = Menu(); // calling the menu() function to intiate the program

            }


        }
        private static bool Menu()
        {


            Console.WriteLine("Select an option: ");
            Console.WriteLine("1- Enter your grades");
            Console.WriteLine("2- Display grades");
            Console.WriteLine("3- Exit Application");

            switch (Console.ReadLine()) // each case number calls a different function
            {
                case "1":

                    StudentGrades();
                    return true;
                case "2":

                    DisplayGrades();
                    return true;

                case "3":

                    Console.WriteLine("Press any key to exit. ");
                    Console.ReadKey();
                    return false;

                default:

                    Console.Clear();
                    Console.WriteLine("The option you selected is not available, please pick a valid option (1-3) ");
                    Console.WriteLine();

                    return true;

            }

        }
        public static void StudentGrades()
        {



            // We declare an integer for all module and one for the average
            string sMark;
            int iMark;
            double dGrades = 0, dFinalGrade = 0;
            string[] Module = new string[6];
            double[] aDoubleGrades = new double[6];

            string Student_Name, Student_Number;

            // Here the user is asked to put his student number
            Console.WriteLine("Enter Student Number :");

            Student_Number = Console.ReadLine();




            // regex here is used to make sure that the user input a 9 digit number, with only numbers
            while (!Regex.IsMatch(Student_Number, "^\\d{9}$"))
            {
                Console.WriteLine("The student number must be a 9 digit number, please try again \n");
                Student_Number = Console.ReadLine();
                Console.WriteLine();
            }


            // Here the user is asked to put his name
            Console.WriteLine("Enter Student Name :");
            Student_Name = Console.ReadLine();

            while (!Regex.IsMatch(Student_Name, @"^[a-zA-Z\s]*$") || Student_Name == "")
            {
                Console.WriteLine("Please enter a valid name.\n");


                Student_Name = Console.ReadLine();

                Console.WriteLine();
            }




            using (StreamWriter sw = new StreamWriter(Student_Number + ".txt", true))  // intialising streamwriter in order to write to a file
            {
                for (int i = 0; i < 6; i++) // for loop to input the grades of all modules
                {
                    // ask user for module name
                    Console.Write("What's your module " + (i + 1) + " name ? ");

                    Module[i] = Console.ReadLine(); // an array is used to store the module names


                    Console.Write("\n");


                    // regex to verify validity of module name
                    while (!Regex.IsMatch(Module[i], @"^[\w\s]*$") || Module[i] == "")
                    {
                        Console.WriteLine("You must enter a valid module name (letters and numbers). Please try again: ");
                        Console.WriteLine();
                        Module[i] = Console.ReadLine();
                        Console.WriteLine();
                    }

                    //ask user for module grade
                    Console.Write("Enter your grade for " + Module[i] + " : "); // using array to store grades

                    sMark = Console.ReadLine();

                    Console.WriteLine("");

                    // make sure its a number between 0-100 

                    while (!Regex.IsMatch(sMark, @"^0*(?:[0-9][0-9]?([\.]\d+)?|100?)$"))
                    {

                        Console.Write("please enter a number between 0-100\n");
                        Console.WriteLine();
                        Console.Write(Module[i] + " : ");
                        sMark = Console.ReadLine();
                        Console.WriteLine();
                    }
                    iMark = Convert.ToInt32(sMark); // smark is converted from string to integer
                    sw.WriteLine(Module[i] + ": " + iMark);
                    // store the results in a file

                    aDoubleGrades[i] = Convert.ToDouble(iMark); // imark is converted from integer to double


                    dGrades = (dGrades + aDoubleGrades[i]); // Sum of all the marks 
                    dFinalGrade = Math.Round((dGrades / 6), 2); // Overall graded rounded up to 2 decimal points

                }

                // The name, average and student number are stored
                sw.WriteLine("student number : " + Student_Number);
                sw.WriteLine("student name : " + Student_Name);
                sw.WriteLine(Student_Name + "'s overall grade is " + dFinalGrade);


                // Here the program will determine if the student passes of fails their term, if they get over 40 they pass, under 40 they fail
                // The result will then be stored
                if (dFinalGrade >= 0 && dFinalGrade < 40)
                {

                    sw.WriteLine(Student_Name + " has failed their term.");

                }


                else if (dFinalGrade >= 40 && dFinalGrade <= 100)
                {

                    sw.WriteLine(Student_Name + " has passed their term.");

                }

                sw.WriteLine(); // blank line
            }

            Console.Write("\r\nPress Enter to return to Main Menu");
            Console.ReadLine();
            Console.Clear();


        }

        public static void DisplayGrades()  // Where the user can chose to display stored student grades
        {
            bool ErrorMessage = false;  // try and catch method is used to make sure that if they write a non-existant student number they are prompted to type a number again
            while (!ErrorMessage)              // While error message not true run try and catch
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("Enter Student Number : ");
                    string Student_Number = Console.ReadLine();
                    Console.WriteLine();

                    using (StreamReader sr = new StreamReader(Student_Number + ".txt"))  // Initialising the streamreader 
                    {
                        while (sr.Peek() != -1)  // returns the object at the beginning without "consuming it.
                        {
                            //Student number is taken from the file
                            Console.WriteLine(sr.ReadLine());




                        }

                    }
                    ErrorMessage = true;
                }
                catch
                {
                    Console.WriteLine("The number that you are looking for doesn't exist. Press any key to try again");
                    Console.ReadKey();
                    ErrorMessage = false;

                }
            }




            Console.Write("\r\nPress Enter to return to Main Menu");
            Console.ReadLine();
            Console.Clear();
        }
    }
}