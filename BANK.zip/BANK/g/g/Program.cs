﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace g
{
    internal class Program
    {
        public static int balance { get; private set; }
        public static string Account_Name { get; private set; }
        public static int Account_Number { get; private set; }


        static void Main(string[] args)
        {
            bool showMenu = true;
            while (showMenu) // while loop makes sure the program still runs at the end of all functions
            {

                showMenu = Menu(); // calling the menu() function to intiate the program

            }

        }

        private static bool Menu()
        {


            Console.WriteLine("Select an option: ");
            Console.WriteLine("1- Create new account");
            Console.WriteLine("2- Withdraw from an existing account");
            Console.WriteLine("3- Deposit into an existing account");
            Console.WriteLine("4- Check balance");
            Console.WriteLine("5- Exit Application");

            switch (Console.ReadLine()) // each case number calls a different function
            {
                case "1":

                    BankAccountClass1.NewAccount(); 
                    return true;

                case "2":

                    BankAccountClass1.Withdraw();
                    return true;

                case "3":

                    BankAccountClass1.Deposit();
                    return true;

                case "4":

                    BankAccountClass1.CheckBalance();
                    return true;

                case "5":

                    Console.WriteLine("Press any key to exit. ");
                    Console.ReadKey();
                    return false;

                default:

                    Console.Clear();
                    Console.WriteLine("The option you selected is not available, please pick a valid option (1-5) ");
                    Console.WriteLine();

                    return true;

            }


        }






    }
}