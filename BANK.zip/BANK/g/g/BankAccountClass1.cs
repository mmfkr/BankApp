﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace g
{
    internal class BankAccountClass1
    {
        
        public static void NewAccount()
        {
            // Generate a random account number
            Random random = new Random();
            int Account_Number = random.Next(1, 1000000000);
            Console.WriteLine($"Account #{Account_Number}");

            // Get the account holder's name
            Console.WriteLine("Enter Name :");
            string Name = Console.ReadLine();

            // Validate the input name
            while (!Regex.IsMatch(Name, @"^[a-zA-Z\s]*$") || Name == "")
            {
                Console.WriteLine("Please enter a valid name.\n");
                Name = Console.ReadLine();
            }

            // Get the starting balance
            Console.WriteLine("Input your starting balance :");
            string Starting_Balance = Console.ReadLine();

            // Validate the input starting balance
            float balance;
            while (!float.TryParse(Starting_Balance, out balance) || balance < 0)
            {
                Console.WriteLine("The starting balance must be a number equal or superior to 0, please type a valid starting balance \n");
                Starting_Balance = Console.ReadLine();
            }

            // Save the input data to a file
            using (StreamWriter writer = new StreamWriter("accounts.txt", true))
            {
                writer.WriteLine($"{Account_Number},{Name},{balance}");


            }
            Console.WriteLine("Account created successfully");
            Console.WriteLine("Press Enter to return to Main Menu");
            Console.ReadLine();
            Console.Clear();
        }

        public static void CheckBalance()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Enter Bank Account Number : ");
                string Account_Number = Console.ReadLine(); // get the account number entered by the user
                Console.Clear();

                if (!int.TryParse(Account_Number, out int accountNumber))
                {
                    Console.WriteLine("Invalid Account Number format. Press any key to try again"); // asking user to try again if they don't write a number
                    Console.ReadKey();
                    continue;
                }
                using (StreamReader sr = new StreamReader("accounts.txt")) // read the accounts.txt file
                {
                    string line;
                    while ((line = sr.ReadLine()) != null) // read each line in the file
                    {
                        // Split the line into an array of strings, where the first element is
                        // the account number and the second element is the account holder name and the third element is the balance
                        string[] accountInfo = line.Split(',');
                        if (accountInfo[0] == Account_Number) // check if the account number entered by the user matches the account number in the file
                        {
                            Console.WriteLine("Account Number: {0}", accountInfo[0]);
                            Console.WriteLine("Account Holder Name:{0} ", accountInfo[1]);
                            Console.WriteLine("Balance:{0} ", accountInfo[2]);
                            Console.WriteLine("Press any key to go back to main menu");
                            Console.ReadKey();
                            Console.Clear();
                            return;
                        }
                    }
                    // asking user to try again if they type in the wrong number 
                    Console.WriteLine("The Bank Account that you are looking for doesn't exist. Press any key to try again");
                    Console.ReadKey();
                }
            }
        }

        public static void Withdraw()
        {
            string Name = "";
            Console.WriteLine("Enter your account number:");
            string Account_Number = Console.ReadLine();  // get the account number entered by the user
            
            
            Console.WriteLine("Enter the amount you want to withdraw:");
            string Amount = Console.ReadLine();  // get the amount entered by the user
            Console.Clear();

            // Validate the input amount
            float amount;
            while (!float.TryParse(Amount, out amount) || amount < 0)
            {
                Console.WriteLine("The amount must be a number equal or superior to 0, please type a valid amount \n");
                Amount = Console.ReadLine();
            }

            bool accountFound = false; //  check if the account was found
            float balance = 0;
            using (StreamReader sr = new StreamReader("accounts.txt")) // read the accounts.txt file
            {


                string line;
                while ((line = sr.ReadLine()) != null) // read each line in the file
                {


                    string[] accountInfo = line.Split(',');

                    if (accountInfo[0] == Account_Number) // check if the account number entered by the user matches the account number in the file
                    {
                        accountFound = true;
                        balance = float.Parse(accountInfo[2]); // get the balance of the account
                        if (amount > balance)
                        {
                            Console.WriteLine("Insufficient balance! Press any key to go back to main menu ");
                            Console.ReadKey();
                            Console.Clear();
                            return;
                        }
                        else
                        {

                            balance -= amount; // subtract the withdrawal amount from the balance
                            Name = (accountInfo[1]);
                        }
                        break;
                    }
                }
            }
            if (!accountFound) // if the account number was not found
            {
                Console.WriteLine("The account number you entered does not exist, press any key to go back to main menu");
                Console.ReadKey();
                Console.Clear();
                return;
            }

            // update the account balance in the file
            string[] lines = File.ReadAllLines("accounts.txt");
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].StartsWith(Account_Number))
                {

                    lines[i] = Account_Number + "," + Name + "," + balance;
                    break;
                }
            }
            File.WriteAllLines("accounts.txt", lines);
            Console.WriteLine("Withdrawal successful! Your new balance is " + balance);
            Console.WriteLine("Press any key to go back to main menu.");
            Console.ReadLine();
            Console.Clear();
        }

        public static void Deposit()
        {
            string Name = "";
            Console.WriteLine("Enter your account number:");
            string Account_Number = Console.ReadLine();  // get the account number entered by the user
            Console.WriteLine("Enter the amount you want to deposit:");
            string Amount = Console.ReadLine();  // get the amount entered by the user
            Console.Clear();

            // Validate the input amount
            float amount;
            while (!float.TryParse(Amount, out amount) || amount < 0)
            {
                Console.WriteLine("The amount must be a number equal or superior to 0, please type a valid amount \n");
                Amount = Console.ReadLine();
            }

            bool accountFound = false; // flag to check if the account was found
            float balance = 0;
            using (StreamReader sr = new StreamReader("accounts.txt")) // read the accounts.txt file
            {
                string line;
                while ((line = sr.ReadLine()) != null) // read each line in the file
                {
                    string[] accountInfo = line.Split(',');

                    if (accountInfo[0] == Account_Number) // check if the account number entered by the user matches the account number in the file
                    {
                        accountFound = true;
                        balance = float.Parse(accountInfo[2]); // get the balance of the account
                        balance += amount; // add the deposit amount to the balance
                        Name = (accountInfo[1]);
                        break;
                    }
                }
            }
            if (!accountFound) // if the account number was not found
            {
                Console.WriteLine("The account number you entered does not exist, press any key to go back to main menu");
                Console.ReadKey();
                Console.Clear();
                return;
            }

            // update the account balance in the file
            string[] lines = File.ReadAllLines("accounts.txt");
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].StartsWith(Account_Number))
                {
                    lines[i] = Account_Number + "," + Name + "," + balance;
                    break;
                }
            }
            File.WriteAllLines("accounts.txt", lines);
            Console.WriteLine("Deposit successful! Your new balance is " + balance);
            Console.WriteLine("Press any key to go back to main menu.");
            Console.ReadLine();
            Console.Clear();
        }
    }
}
